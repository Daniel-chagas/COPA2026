using System;

namespace Copa2026
{
    static class SelecaoCrud
    {
        public static void Cadastrar()
        {
            UI.Cabecalho("CADASTRAR SELEÇÃO");

            // Conta apenas as seleções ativas
            int ativas = 0;
            for (int i = 0; i < Dados.totalSelecoes; i++)
                if (Dados.selecoes[i].Ativo) ativas++;

            if (ativas >= Dados.MAX_SELECOES)
            {
                UI.Erro("Limite de 48 seleções atingido.");
                UI.Pausar();
                return;
            }

            string nome = UI.LerString("Nome da seleção : ");

            string grupo;
            while (true)
            {
                grupo = UI.LerString("Grupo (A-L)      : ").ToUpper();
                if (!Dados.GrupoValido(grupo)) { UI.Erro("Grupo inválido. Use A até L."); continue; }
                if (Dados.SelecoesPorGrupo(grupo) >= 4) { UI.Erro("Grupo já tem 4 seleções."); continue; }
                break;
            }

            // Reutiliza slot de seleção excluída, ou usa o próximo livre
            int idx = Dados.totalSelecoes;
            for (int i = 0; i < Dados.totalSelecoes; i++)
            {
                if (!Dados.selecoes[i].Ativo) { idx = i; break; }
            }
            if (idx == Dados.totalSelecoes) Dados.totalSelecoes++;

            Dados.selecoes[idx].Id = Dados.ProximoIdSelecao();
            Dados.selecoes[idx].Nome = nome;
            Dados.selecoes[idx].Grupo = grupo;
            Dados.selecoes[idx].Ativo = true;

            UI.Sucesso($"Seleção '{nome}' cadastrada com ID {Dados.selecoes[idx].Id}.");
            UI.Pausar();
        }

        public static void Listar()
        {
            UI.Cabecalho("SELEÇÕES CADASTRADAS");

            int[] indices = new int[Dados.totalSelecoes];
            int n = 0;
            for (int i = 0; i < Dados.totalSelecoes; i++)
                if (Dados.selecoes[i].Ativo) indices[n++] = i;

            if (n == 0) { UI.Info("Nenhuma seleção cadastrada."); UI.Pausar(); return; }

            // Ordena por Grupo (A-L) e, dentro do mesmo grupo, por ID
            for (int a = 0; a < n - 1; a++)
                for (int b = a + 1; b < n; b++)
                {
                    var sA = Dados.selecoes[indices[a]];
                    var sB = Dados.selecoes[indices[b]];
                    int cmp = string.Compare(sA.Grupo, sB.Grupo, StringComparison.OrdinalIgnoreCase);
                    if (cmp > 0 || (cmp == 0 && sA.Id > sB.Id))
                    { int tmp = indices[a]; indices[a] = indices[b]; indices[b] = tmp; }
                }

            Console.WriteLine($"{"ID",-5} {"Nome",-25} {"Grupo",-6}");
            Console.WriteLine(new string('-', 38));

            string grupoAtual = "";
            for (int i = 0; i < n; i++)
            {
                var s = Dados.selecoes[indices[i]];
                if (s.Grupo != grupoAtual)
                {
                    if (grupoAtual != "") Console.WriteLine();
                    grupoAtual = s.Grupo;
                }
                Console.WriteLine($"{s.Id,-5} {s.Nome,-25} {s.Grupo,-6}");
            }

            UI.Pausar();
        }

        public static void Alterar()
        {
            UI.Cabecalho("ALTERAR SELEÇÃO");
            int id = UI.LerInt("ID da seleção : ", 1);
            int idx = Dados.IndexSelecao(id);
            if (idx < 0) { UI.Erro("Seleção não encontrada."); UI.Pausar(); return; }

            Console.WriteLine($"Seleção atual: {Dados.selecoes[idx].Nome} | Grupo: {Dados.selecoes[idx].Grupo}");

            string nome = UI.LerString("Novo nome (ENTER para manter) : ", false);
            if (nome.Length > 0) Dados.selecoes[idx].Nome = nome;

            string grupo;
            while (true)
            {
                grupo = UI.LerString("Novo grupo A-L (ENTER para manter) : ", false).ToUpper();
                if (grupo.Length == 0) break;
                if (!Dados.GrupoValido(grupo)) { UI.Erro("Grupo inválido."); continue; }
                int count = 0;
                for (int i = 0; i < Dados.totalSelecoes; i++)
                    if (i != idx && Dados.selecoes[i].Ativo &&
                        Dados.selecoes[i].Grupo == grupo) count++;
                if (count >= 4) { UI.Erro("Grupo já tem 4 seleções."); continue; }
                Dados.selecoes[idx].Grupo = grupo;
                break;
            }

            UI.Sucesso("Seleção alterada.");
            UI.Pausar();
        }

        public static void Excluir()
        {
            UI.Cabecalho("EXCLUIR SELEÇÃO");
            int id = UI.LerInt("ID da seleção : ", 1);
            int idx = Dados.IndexSelecao(id);
            if (idx < 0) { UI.Erro("Seleção não encontrada."); UI.Pausar(); return; }

            Console.Write($"Confirma exclusão de '{Dados.selecoes[idx].Nome}'? (S/N) : ");
            string conf = Console.ReadLine()?.Trim().ToUpper() ?? "";
            if (conf == "S")
            {
                Dados.selecoes[idx].Ativo = false;
                UI.Sucesso("Seleção excluída (exclusão lógica).");
            }
            else UI.Info("Operação cancelada.");
            UI.Pausar();
        }
    }
}